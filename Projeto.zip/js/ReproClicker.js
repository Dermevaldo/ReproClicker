var ponto=0;
var bonus = 0;
var item1=0;
var item1U=1;
item1Custo=10;
item1UCusto=100;
$(".item1UCusto").text(item1UCusto);

function trocar(){
	$(".upgrade").toggle();
	$(".recursos").toggle();
}
function iniciar(){
	$(".ponto").text(ponto);
	$(".item1Q").text(item1);
	$(".item1UTexto").text(Upgrade1Texto[item1U-1]);
	$(".upgrade").hide();
}
function clica(){
	ponto++;
	ponto+=item1*item1U;

	$(".ponto").text(ponto);
}
function item1T(){
if (ponto>=item1Custo) 
{
	item1++;
	ponto-=item1Custo;
	item1Custo+=Math.round(0.40*item1Custo);
	$(".item1Q").text(item1);
	$(".ponto").text(ponto);
	$(".item1C").text(item1Custo);	
}}
 function item1UCompra(){
 if (ponto>=item1UCusto) {
 		item1U++;
 		item1UCusto+=item1Custo*10;
	$(".ponto").text(ponto);
	$(".item1UCusto").text(item1UCusto);
	$(".item1UTexto").text(Upgrade1Texto[item1U-1]);
 	}	
 }